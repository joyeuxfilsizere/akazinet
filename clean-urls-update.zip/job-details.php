<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/components/whatsapp.php';
require_once __DIR__ . '/components/ad-banner.php';
require_once __DIR__ . '/components/job-card.php';

$slug = $_GET['slug'] ?? '';
if (empty($slug)) {
    redirect('/jobs');
}

$stmt = $pdo->prepare("
    SELECT j.*, cat.name as category_name, cat.slug as category_slug
    FROM jobs j
    JOIN categories cat ON j.category_id = cat.id
    WHERE j.slug = ? AND j.status = 'published' AND j.is_active = 1
");
$stmt->execute([$slug]);
$job = $stmt->fetch();

if (!$job) {
    redirect('/jobs');
}

$pdo->prepare("UPDATE jobs SET views = views + 1 WHERE id = ?")->execute([$job['id']]);

$isExpired = $job['application_deadline'] && strtotime($job['application_deadline']) < time();
$deadline = $job['application_deadline'] ? date('F d, Y', strtotime($job['application_deadline'])) : 'Open';

$whatsappNumber = get_setting('whatsapp_number', '250780092252');

$relatedJobs = $pdo->prepare("
    SELECT j.*, cat.name as category_name
    FROM jobs j
    JOIN categories cat ON j.category_id = cat.id
    WHERE j.category_id = ? AND j.id != ? AND j.status = 'published' AND j.is_active = 1
    ORDER BY j.created_at DESC LIMIT 3
");
$relatedJobs->execute([$job['category_id'], $job['id']]);
$relatedJobs = $relatedJobs->fetchAll();

$pageTitle = $job['title'];
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<section class="bg-gradient-to-br from-primary to-primary-dark py-8">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <a href="/jobs" class="inline-flex items-center text-gray-300 hover:text-white text-sm mb-4 transition-colors">
            <i class="fas fa-arrow-left mr-2"></i> Back to Jobs
        </a>
    </div>
</section>

<section class="py-8 md:py-12 bg-brand-gray">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Main Content -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Job Header -->
                <div class="bg-white rounded-xl p-6 md:p-8 border border-brand-border shadow-sm">
                    <div class="flex items-start space-x-5">
                        <div class="w-16 h-16 rounded-xl overflow-hidden bg-gray-50 border border-brand-border flex-shrink-0 flex items-center justify-center">
                            <?php $jobLogo = !empty($job['company_logo']) ? '/assets/uploads/' . $job['company_logo'] : '/assets/images/default-logo.svg'; ?>
                            <img src="<?= $jobLogo ?>" alt="<?= $job['company_name'] ?>" class="w-full h-full object-contain p-1" onerror="this.src='/assets/images/default-logo.svg'">
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-start justify-between">
                                <div>
                                    <?php if ($job['is_featured']): ?>
                                    <span class="inline-flex items-center text-xs font-semibold text-accent bg-accent/10 px-2.5 py-1 rounded-full mb-2">
                                        <i class="fas fa-star mr-1"></i> Featured
                                    </span>
                                    <?php endif; ?>
                                    <?php if ($isExpired): ?>
                                    <span class="inline-flex items-center text-xs font-semibold text-red-600 bg-red-50 px-2.5 py-1 rounded-full mb-2 ml-2">
                                        Expired
                                    </span>
                                    <?php endif; ?>
                                    <h1 class="text-2xl md:text-3xl font-bold text-gray-900"><?= sanitize($job['title']) ?></h1>
                                    <span class="text-primary font-medium"><?= sanitize($job['company_name']) ?></span>
                                </div>
                            </div>
                            <div class="flex flex-wrap gap-2 mt-4">
                                <span class="inline-flex items-center text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg">
                                    <i class="fas fa-map-marker-alt mr-1.5 text-primary-light"></i> <?= sanitize($job['location'] ?? $job['district'] . ', ' . $job['province']) ?>
                                </span>
                                <span class="inline-flex items-center text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg">
                                    <i class="fas fa-briefcase mr-1.5 text-primary-light"></i> <?= sanitize($job['employment_type']) ?>
                                </span>
                                <span class="inline-flex items-center text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg">
                                    <i class="fas fa-tag mr-1.5 text-primary-light"></i> <?= sanitize($job['category_name']) ?>
                                </span>
                                <?php if ($job['experience_level']): ?>
                                <span class="inline-flex items-center text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg">
                                    <i class="fas fa-layer-group mr-1.5 text-primary-light"></i> <?= sanitize($job['experience_level']) ?>
                                </span>
                                <?php endif; ?>
                                <?php if ($job['education_level']): ?>
                                <span class="inline-flex items-center text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg">
                                    <i class="fas fa-graduation-cap mr-1.5 text-primary-light"></i> <?= sanitize($job['education_level']) ?>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Description -->
                <?php if ($job['description']): ?>
                <div class="bg-white rounded-xl p-6 md:p-8 border border-brand-border shadow-sm">
                    <h2 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <span class="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-file-alt text-primary text-sm"></i>
                        </span>
                        Job Description
                    </h2>
                    <div class="text-gray-600 leading-relaxed whitespace-pre-line"><?= nl2br(sanitize($job['description'])) ?></div>
                </div>
                <?php endif; ?>

                <?php if ($job['responsibilities']): ?>
                <div class="bg-white rounded-xl p-6 md:p-8 border border-brand-border shadow-sm">
                    <h2 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <span class="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-tasks text-accent text-sm"></i>
                        </span>
                        Responsibilities
                    </h2>
                    <ul class="space-y-2">
                        <?php foreach (explode("\n", $job['responsibilities']) as $item): ?>
                        <?php if (trim($item)): ?>
                        <li class="flex items-start text-gray-600 text-sm">
                            <i class="fas fa-check-circle text-secondary-light mt-0.5 mr-3 flex-shrink-0"></i>
                            <?= sanitize(trim($item)) ?>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ($job['requirements']): ?>
                <div class="bg-white rounded-xl p-6 md:p-8 border border-brand-border shadow-sm">
                    <h2 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <span class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-clipboard-list text-blue-500 text-sm"></i>
                        </span>
                        Requirements
                    </h2>
                    <ul class="space-y-2">
                        <?php foreach (explode("\n", $job['requirements']) as $item): ?>
                        <?php if (trim($item)): ?>
                        <li class="flex items-start text-gray-600 text-sm">
                            <i class="fas fa-check-circle text-secondary-light mt-0.5 mr-3 flex-shrink-0"></i>
                            <?= sanitize(trim($item)) ?>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ($job['qualifications']): ?>
                <div class="bg-white rounded-xl p-6 md:p-8 border border-brand-border shadow-sm">
                    <h2 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <span class="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-award text-purple-500 text-sm"></i>
                        </span>
                        Qualifications
                    </h2>
                    <ul class="space-y-2">
                        <?php foreach (explode("\n", $job['qualifications']) as $item): ?>
                        <?php if (trim($item)): ?>
                        <li class="flex items-start text-gray-600 text-sm">
                            <i class="fas fa-check-circle text-secondary-light mt-0.5 mr-3 flex-shrink-0"></i>
                            <?= sanitize(trim($item)) ?>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ($job['benefits']): ?>
                <div class="bg-white rounded-xl p-6 md:p-8 border border-brand-border shadow-sm">
                    <h2 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <span class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-gift text-green-500 text-sm"></i>
                        </span>
                        Benefits
                    </h2>
                    <ul class="space-y-2">
                        <?php foreach (explode("\n", $job['benefits']) as $item): ?>
                        <?php if (trim($item)): ?>
                        <li class="flex items-start text-gray-600 text-sm">
                            <i class="fas fa-check-circle text-secondary-light mt-0.5 mr-3 flex-shrink-0"></i>
                            <?= sanitize(trim($item)) ?>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ($job['how_to_apply']): ?>
                <div class="bg-white rounded-xl p-6 md:p-8 border border-brand-border shadow-sm">
                    <h2 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <span class="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-paper-plane text-orange-500 text-sm"></i>
                        </span>
                        How to Apply
                    </h2>
                    <div class="text-gray-600 leading-relaxed whitespace-pre-line"><?= nl2br(preg_replace('/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/', '<strong>$1</strong>', preg_replace('/(https?:\/\/[^\s<]+)/', '<a href="$1" target="_blank" rel="noopener noreferrer" class="text-primary font-semibold hover:underline">$1</a>', sanitize($job['how_to_apply'])))) ?></div>
                </div>
                <?php endif; ?>

                <!-- Share -->
                <div class="bg-white rounded-xl p-6 border border-brand-border shadow-sm">
                    <div class="flex items-center justify-between flex-wrap gap-4">
                        <h3 class="font-semibold text-gray-900"><i class="fas fa-share-alt mr-2 text-primary"></i>Share This Vacancy</h3>
                        <div class="flex space-x-2">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(SITE_URL . $_SERVER['REQUEST_URI']) ?>" target="_blank" class="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center hover:bg-blue-700 transition-colors" aria-label="Share on Facebook"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://www.instagram.com/" target="_blank" class="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400 text-white flex items-center justify-center hover:opacity-90 transition-colors" aria-label="Share on Instagram"><i class="fab fa-instagram"></i></a>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?= urlencode(SITE_URL . $_SERVER['REQUEST_URI']) ?>&title=<?= urlencode($job['title']) ?>" target="_blank" class="w-10 h-10 rounded-lg bg-blue-700 text-white flex items-center justify-center hover:bg-blue-800 transition-colors" aria-label="Share on LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                            <a href="https://wa.me/?text=<?= urlencode($job['title'] . ' at ' . $job['company_name'] . "\n" . SITE_URL . $_SERVER['REQUEST_URI']) ?>" target="_blank" class="w-10 h-10 rounded-lg bg-green-500 text-white flex items-center justify-center hover:bg-green-600 transition-colors" aria-label="Share on WhatsApp"><i class="fab fa-whatsapp"></i></a>
                        </div>
                    </div>
                </div>

                <!-- WhatsApp -->
                <?php render_whatsapp_button($job['title'], $job['company_name'], $whatsappNumber); ?>
            </div>

            <!-- Sidebar -->
            <div class="space-y-6">
                <!-- Job Info -->
                <div class="bg-white rounded-xl p-6 border border-brand-border shadow-sm">
                    <h3 class="font-bold text-gray-900 mb-4">Job Information</h3>
                    <div class="space-y-4">
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-500">Company</span>
                            <span class="font-medium text-gray-800"><?= sanitize($job['company_name']) ?></span>
                        </div>
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-500">Posted</span>
                            <span class="font-medium text-gray-800"><?= date('M d, Y', strtotime($job['created_at'])) ?></span>
                        </div>
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-500">Deadline</span>
                            <span class="font-medium <?= $isExpired ? 'text-red-500' : 'text-gray-800' ?>"><?= $isExpired ? 'Expired' : $deadline ?></span>
                        </div>
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-500">Views</span>
                            <span class="font-medium text-gray-800"><?= $job['views'] ?></span>
                        </div>
                    </div>
                </div>

                <!-- Advertisement -->
                <?php render_ad_banner(['sidebar', 'content']); ?>

                <?php if (!$isExpired): ?>
                <?php
                    $applyUrl = !empty($job['application_url']) ? $job['application_url'] : '';
                    $applyEmail = !empty($job['application_email']) ? $job['application_email'] : '';
                    $waMsg = urlencode("Hello,\nI'm interested in this job position\nJob name: {$job['title']}\nAt: {$job['company_name']}\nI would like you to help me to apply\nThank you 🙏");
                    $waUrl = "https://wa.me/{$whatsappNumber}?text={$waMsg}";
                ?>

                <!-- Apply Now -->
                <?php if ($applyUrl): ?>
                <a href="<?= sanitize($applyUrl) ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-full py-4 bg-primary text-white text-center font-bold text-lg rounded-xl hover:bg-primary-dark transition-all duration-300 hover:shadow-lg">
                    <i class="fas fa-external-link-alt mr-2"></i> Apply Now
                </a>
                <?php elseif ($applyEmail): ?>
                <a href="mailto:<?= sanitize($applyEmail) ?>" class="flex items-center justify-center w-full py-4 bg-primary text-white text-center font-bold text-lg rounded-xl hover:bg-primary-dark transition-all duration-300 hover:shadow-lg">
                    <i class="fas fa-envelope mr-2"></i> Apply Now
                </a>
                <?php endif; ?>

                <!-- Ask for Help -->
                <a href="<?= $waUrl ?>" target="_blank" class="flex items-center justify-center w-full py-4 mt-3 bg-green-500 text-white text-center font-bold text-lg rounded-xl hover:bg-green-600 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/25">
                    <i class="fab fa-whatsapp mr-2 text-xl"></i> Ask for Help
                </a>

                <!-- Application Email - Prominent Display -->
                <?php if ($applyEmail): ?>
                <div class="mt-4 bg-blue-50 border border-blue-200 rounded-xl p-5 text-center">
                    <div class="flex items-center justify-center mb-2">
                        <span class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-2">
                            <i class="fas fa-envelope text-blue-600 text-lg"></i>
                        </span>
                        <span class="text-sm font-semibold text-blue-800 uppercase tracking-wide">Send your CV to</span>
                    </div>
                    <a href="mailto:<?= sanitize($applyEmail) ?>" class="inline-block text-xl md:text-2xl font-extrabold text-blue-700 break-all hover:underline">
                        <?= sanitize($applyEmail) ?>
                    </a>
                    <p class="text-xs text-blue-500 mt-2">Click the email address to open your mail app</p>
                </div>
                <?php endif; ?>

                <!-- Application URL - Info Display -->
                <?php if ($applyUrl): ?>
                <div class="mt-4 bg-green-50 border border-green-200 rounded-xl p-5 text-center">
                    <div class="flex items-center justify-center mb-2">
                        <span class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-2">
                            <i class="fas fa-globe text-green-600 text-lg"></i>
                        </span>
                        <span class="text-sm font-semibold text-green-800 uppercase tracking-wide">Apply on website</span>
                    </div>
                    <a href="<?= sanitize($applyUrl) ?>" target="_blank" rel="noopener noreferrer" class="inline-block text-sm md:text-base font-bold text-green-700 break-all hover:underline">
                        <?= sanitize($applyUrl) ?>
                    </a>
                </div>
                <?php endif; ?>

                <?php endif; ?>
            </div>
        </div>

        <!-- Related Jobs -->
        <?php if (!empty($relatedJobs)): ?>
        <div class="mt-12">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Related Jobs</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <?php foreach ($relatedJobs as $rjob): ?>
                <?php render_job_card($rjob); ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Footer Banner -->
<?php render_ad_banner('footer'); ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
</body>
</html>

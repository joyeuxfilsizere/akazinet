<?php $isAdmin = is_admin_logged_in(); ?>
<style>body { padding-top: 92px; }</style>
<nav class="floating-navbar" id="navbar">
    <div class="floating-navbar-container" id="navbarContainer">
        <div class="floating-navbar-inner">

            <!-- Logo -->
            <a href="/" class="navbar-logo">
                <img src="/assets/images/logo.svg" alt="AkaziNet" class="h-10 w-auto" />
            </a>

            <!-- Desktop Navigation -->
            <div class="navbar-nav">

                <a href="/" class="nav-item <?= $currentPage === 'index' ? 'active' : '' ?>">
                    <span class="nav-item-text">Home</span>
                    <?php if ($currentPage === 'index'): ?><span class="nav-indicator"></span><?php endif; ?>
                </a>

                <a href="/jobs" class="nav-item <?= $currentPage === 'jobs' ? 'active' : '' ?>">
                    <span class="nav-item-text">Jobs</span>
                    <?php if ($currentPage === 'jobs'): ?><span class="nav-indicator"></span><?php endif; ?>
                </a>

                <!-- Dropdown: Explore -->
                <div class="nav-dropdown" id="exploreDropdown">
                    <button class="nav-item nav-dropdown-trigger <?= $currentPage === 'categories' || $currentPage === 'scholarships' ? 'active' : '' ?>" aria-expanded="false" aria-haspopup="true">
                        <span class="nav-item-text">Explore</span>
                        <i class="fas fa-chevron-down nav-chevron"></i>
                    </button>
                    <div class="nav-dropdown-menu" role="menu">
                        <div class="nav-dropdown-arrow"></div>
                        <a href="/pages/categories" class="dropdown-item" role="menuitem">
                            <div class="dropdown-item-icon">
                                <i class="fas fa-th-large"></i>
                            </div>
                            <div>
                                <div class="dropdown-item-label">Categories</div>
                                <div class="dropdown-item-desc">Browse by job category</div>
                            </div>
                        </a>
                        <a href="/pages/scholarships" class="dropdown-item" role="menuitem">
                            <div class="dropdown-item-icon accent">
                                <i class="fas fa-graduation-cap"></i>
                            </div>
                            <div>
                                <div class="dropdown-item-label">Scholarships</div>
                                <div class="dropdown-item-desc">Educational opportunities</div>
                            </div>
                        </a>
                        <a href="/companies" class="dropdown-item" role="menuitem">
                            <div class="dropdown-item-icon green">
                                <i class="fas fa-building"></i>
                            </div>
                            <div>
                                <div class="dropdown-item-label">Companies</div>
                                <div class="dropdown-item-desc">Top employers in Rwanda</div>
                            </div>
                        </a>
                    </div>
                </div>

                <a href="/pages/about" class="nav-item <?= $currentPage === 'about' ? 'active' : '' ?>">
                    <span class="nav-item-text">About</span>
                    <?php if ($currentPage === 'about'): ?><span class="nav-indicator"></span><?php endif; ?>
                </a>

                <a href="/pages/contact" class="nav-item <?= $currentPage === 'contact' ? 'active' : '' ?>">
                    <span class="nav-item-text">Contact</span>
                    <?php if ($currentPage === 'contact'): ?><span class="nav-indicator"></span><?php endif; ?>
                </a>
            </div>

            <!-- Right Actions -->
            <div class="navbar-actions">
                <?php if ($isAdmin): ?>
                    <a href="/admin/" class="nav-btn nav-btn-ghost" title="Admin Dashboard">
                        <i class="fas fa-cog"></i>
                        <span class="nav-btn-label">Dashboard</span>
                    </a>
                    <a href="/admin/logout" class="nav-btn nav-btn-ghost" title="Sign Out">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                    <a href="/admin/jobs" class="nav-btn nav-btn-primary" title="Post a Job">
                        <i class="fas fa-plus"></i>
                        <span class="nav-btn-label">Post Job</span>
                    </a>
                <?php endif; ?>
            </div>

            <!-- Mobile Toggle -->
            <button class="navbar-mobile-toggle" id="mobileMenuBtn" aria-label="Toggle menu" aria-expanded="false">
                <span class="hamburger-line"></span>
                <span class="hamburger-line"></span>
                <span class="hamburger-line"></span>
            </button>
        </div>
    </div>

    <!-- Mobile Menu -->
    <div class="mobile-menu" id="mobileMenu" aria-hidden="true">
        <div class="mobile-menu-inner">

            <a href="/" class="mobile-nav-item <?= $currentPage === 'index' ? 'active' : '' ?>">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="/jobs" class="mobile-nav-item <?= $currentPage === 'jobs' ? 'active' : '' ?>">
                <i class="fas fa-briefcase"></i> Jobs
            </a>
            <a href="/pages/categories" class="mobile-nav-item <?= $currentPage === 'categories' ? 'active' : '' ?>">
                <i class="fas fa-th-large"></i> Categories
            </a>
            <a href="/pages/scholarships" class="mobile-nav-item <?= $currentPage === 'scholarships' ? 'active' : '' ?>">
                <i class="fas fa-graduation-cap"></i> Scholarships
            </a>
            <a href="/companies" class="mobile-nav-item <?= $currentPage === 'companies' ? 'active' : '' ?>">
                <i class="fas fa-building"></i> Companies
            </a>
            <a href="/pages/about" class="mobile-nav-item <?= $currentPage === 'about' ? 'active' : '' ?>">
                <i class="fas fa-info-circle"></i> About
            </a>
            <a href="/pages/contact" class="mobile-nav-item <?= $currentPage === 'contact' ? 'active' : '' ?>">
                <i class="fas fa-envelope"></i> Contact
            </a>

            <div class="mobile-menu-divider"></div>

            <?php if ($isAdmin): ?>
                <a href="/admin/" class="mobile-nav-item">
                    <i class="fas fa-cog"></i> Dashboard
                </a>
                <a href="/admin/jobs" class="mobile-cta-btn">
                    <i class="fas fa-plus"></i> Post a Job
                </a>
                <a href="/admin/logout" class="mobile-nav-item">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

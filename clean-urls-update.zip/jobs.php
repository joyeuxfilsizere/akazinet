<?php
$pageTitle = 'Browse Jobs';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/components/job-card.php';
require_once __DIR__ . '/components/ad-banner.php';

$search = $_GET['search'] ?? '';
$province = $_GET['province'] ?? '';
$category = $_GET['category'] ?? '';
$featured = isset($_GET['featured']) ? 1 : 0;
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;

$where = ["j.status = 'published'", "j.is_active = 1"];
$params = [];

if (!empty($search)) {
    $where[] = "(j.title LIKE ? OR j.company_name LIKE ? OR j.description LIKE ?)";
    $like = "%{$search}%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}
if (!empty($province)) {
    $where[] = "j.province = ?";
    $params[] = $province;
}
if (!empty($category)) {
    $where[] = "cat.slug = ?";
    $params[] = $category;
}
if ($featured) {
    $where[] = "j.is_featured = 1";
}

$whereSQL = implode(' AND ', $where);

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM jobs j JOIN categories cat ON j.category_id = cat.id WHERE {$whereSQL}");
$countStmt->execute($params);
$total = $countResult = $countStmt->fetchColumn();

$pagination = paginate($total, $perPage, $page);

$stmt = $pdo->prepare("
    SELECT j.*, cat.name as category_name, cat.slug as category_slug
    FROM jobs j
    JOIN categories cat ON j.category_id = cat.id
    WHERE {$whereSQL}
    ORDER BY j.is_featured DESC, j.created_at DESC
    LIMIT {$perPage} OFFSET {$pagination['offset']}
");
$stmt->execute($params);
$jobs = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY name")->fetchAll();

require_once __DIR__ . '/includes/navbar.php';
?>

<!-- Hero Section -->
<section class="bg-gradient-to-br from-primary to-primary-dark py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-8">
            <h1 class="text-3xl md:text-4xl font-bold text-white mb-3">
                <?php if ($featured): ?>
                    Featured Jobs
                <?php elseif (!empty($search)): ?>
                    Search Results
                <?php else: ?>
                    Browse All Jobs
                <?php endif; ?>
            </h1>
            <p class="text-gray-400 text-lg"><?= $total ?> job<?= $total !== 1 ? 's' : '' ?> found</p>
        </div>

        <!-- Search Form -->
        <form action="/jobs" method="GET" class="bg-white rounded-2xl p-3 shadow-2xl max-w-3xl mx-auto">
            <div class="flex flex-col md:flex-row gap-3">
                <div class="flex-1 relative">
                    <i class="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                    <input type="text" name="search" value="<?= sanitize($search) ?>" placeholder="Job title, company, or keyword..." class="w-full pl-12 pr-4 py-3.5 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all text-gray-700">
                </div>
                <div class="flex-1 relative">
                    <i class="fas fa-map-marker-alt absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                    <select name="province" class="w-full pl-12 pr-4 py-3.5 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all text-gray-700 appearance-none bg-white">
                        <option value="">All Locations</option>
                        <?php foreach (['Kigali', 'Northern', 'Southern', 'Eastern', 'Western'] as $loc): ?>
                        <option value="<?= $loc ?>" <?= $province === $loc ? 'selected' : '' ?>><?= $loc ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="px-8 py-3.5 bg-accent text-white font-semibold rounded-xl hover:bg-accent-light transition-all duration-300 hover:shadow-lg hover:shadow-accent/30 flex items-center justify-center">
                    <i class="fas fa-search mr-2"></i> Search
                </button>
            </div>
        </form>
    </div>
</section>

<!-- Filters & Results -->
<section class="py-12 bg-brand-gray min-h-[50vh]">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <!-- Category Chips -->
        <div class="flex flex-wrap gap-2 mb-8">
            <a href="/jobs" class="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium transition-colors <?= empty($category) ? 'bg-primary text-white' : 'bg-white text-gray-600 border border-brand-border hover:border-primary hover:text-primary' ?>">
                All
            </a>
            <?php foreach ($categories as $cat): ?>
            <a href="/jobs?category=<?= $cat['slug'] ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= !empty($province) ? '&province=' . urlencode($province) : '' ?>" class="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium transition-colors <?= $category === $cat['slug'] ? 'bg-primary text-white' : 'bg-white text-gray-600 border border-brand-border hover:border-primary hover:text-primary' ?>">
                <i class="fas fa-<?= $cat['icon'] ?> mr-1.5"></i> <?= sanitize($cat['name']) ?>
            </a>
            <?php endforeach; ?>
        </div>

        <!-- Ad Banner -->
        <?php render_ad_banner('content'); ?>

        <?php if (!empty($jobs)): ?>
        <!-- Job Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
            <?php foreach ($jobs as $job): ?>
                <?php render_job_card($job); ?>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($pagination['total_pages'] > 1): ?>
        <nav class="flex items-center justify-center gap-2">
            <?php if ($pagination['has_prev']): ?>
            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" class="px-4 py-2 bg-white border border-brand-border rounded-lg text-sm font-medium text-gray-600 hover:border-primary hover:text-primary transition-colors">
                <i class="fas fa-arrow-left mr-1"></i> Prev
            </a>
            <?php endif; ?>

            <?php for ($i = max(1, $page - 2); $i <= min($pagination['total_pages'], $page + 2); $i++): ?>
            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" class="w-10 h-10 flex items-center justify-center rounded-lg text-sm font-medium transition-colors <?= $i === $page ? 'bg-primary text-white' : 'bg-white border border-brand-border text-gray-600 hover:border-primary hover:text-primary' ?>">
                <?= $i ?>
            </a>
            <?php endfor; ?>

            <?php if ($pagination['has_next']): ?>
            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" class="px-4 py-2 bg-white border border-brand-border rounded-lg text-sm font-medium text-gray-600 hover:border-primary hover:text-primary transition-colors">
                Next <i class="fas fa-arrow-right ml-1"></i>
            </a>
            <?php endif; ?>
        </nav>
        <?php endif; ?>

        <?php else: ?>
        <!-- Empty State -->
        <div class="text-center py-20">
            <div class="w-20 h-20 mx-auto mb-6 bg-gray-100 rounded-2xl flex items-center justify-center">
                <i class="fas fa-search text-gray-300 text-3xl"></i>
            </div>
            <h2 class="text-2xl font-bold text-gray-900 mb-2">No jobs found</h2>
            <p class="text-gray-500 mb-6">Try adjusting your search criteria or browse all jobs.</p>
            <a href="/jobs" class="inline-flex items-center px-6 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-primary-dark transition-colors">
                <i class="fas fa-list mr-2"></i> Browse All Jobs
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Footer Banner -->
<?php render_ad_banner('footer'); ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
